# RiveScript powered chat bot example

This is an example of 1-to-1 chatbot with [RiveScript](https://www.rivescript.com)  scripting language integrated, making it easy to write trigger/response pairs for building up a bot's intelligence.

# Guide
Read Chat Bots guide to understand how to build own bot for QuickBlox with RiveScript.

[https://quickblox.com/developers/ChatBots](https://quickblox.com/developers/ChatBots)

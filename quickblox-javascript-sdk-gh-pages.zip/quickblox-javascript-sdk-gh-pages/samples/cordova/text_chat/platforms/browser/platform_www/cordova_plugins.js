cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-websocket": "0.12.0",
    "cordova-plugin-whitelist": "1.3.0",
    "cordova-plugin-console": "1.0.4",
    "cordova-custom-config": "3.0.14"
}
// BOTTOM OF METADATA
});
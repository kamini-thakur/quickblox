*Help avoid duplicate issue reports, check [existing issues](https://github.com/QuickBlox/quickblox-javascript-sdk/issues)*

**Environment details**
*(Operating system, browser information, SDK version)*


**Did this work before?**


**Expected behavior**


**Actual behavior**


**Logs**
*(please, switch on a [debugging mode](http://quickblox.com/developers/Javascript#Configuration) and share us outputs uses github [gist](https://gist.github.com/))*


**Steps to reproduce the behavior**


**Any others comments?**
